// import express and create router object
let express = require('express');
let router = express.Router();

// '/' actually considered as /about because > about is the name of my contollers
router.get('/', (request, repsonse, next) => {

    let tools =[
          {'name': 'Node'}, 
          {'name': 'Express'}, 
          {'name': 'Handlebars'}, 
          {'name': 'Three'}
        ] // this is the model
        
        
        // this is also a json objects
         response.render('about',
             {
                title: 'About Me', 
                tools:tools
             }); 
});

module.exports = router; // < router configuration is available