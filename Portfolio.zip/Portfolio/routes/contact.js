// import express and create objects
var express = require('express');
var router = express.Router();


router.get('/', (request, repsonse, next) => {
response.render('Contact Me',
             {
                title:'Contact Me', 
             }); 
});

module.exports = router;