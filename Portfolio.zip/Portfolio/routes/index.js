// router/controller file
var express = require('express');
var router = express.Router();

/* GET home page. */
// same as contact > function with three objects(parameters)
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/about',(request, response, next) => {
// pass more data > alternatively this could come from DB(Mongo - json)
let tools =[
  {'name': 'Node'}, 
  {'name': 'Express'}, 
  {'name': 'Handlebars'}, 
  {'name': 'Three'}
] // this is the model


// this is also a json objects
 response.render('about',
     {
        title: 'About Me', 
        tools:tools
     });
});

module.exports = router;
 